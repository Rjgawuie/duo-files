/******************************************************************************
 * The MIT License
 *
 * Copyright (c) 2010, LeafLabs, LLC.
 *
 * Permission is hereby granted, free of charge, to any person
 * obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without
 * restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies
 * of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be
 * included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND,
 * EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
 * MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 * NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS
 * BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN
 * ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 *****************************************************************************/
#if defined(ARDUINO_ARCH_SG200X)

#include "ServoTimers.h"
#include "wiring_digital.h"
#include "cvi_pwm.h"

// 20 millisecond period config. For a 1-based prescaler,
#define CYCLE_PERIOD_MS        20

// Unit conversions
#define MAP(a,b,c,d,e)    ((float)(a-b)/(c-b)*(e-d)+d)
#define ANGLE_TO_US(a)    ((uint16_t)(MAP((a), this->minAngle, this->maxAngle, \
                                        this->minPW, this->maxPW)))
#define US_TO_ANGLE(us)   ((int16_t)(MAP((us), this->minPW, this->maxPW,  \
                                       this->minAngle, this->maxAngle)))


extern dev_pin_map_t pwm_map[];
extern pin_name_t out_pin_map[];

Servo::Servo() {
    this->resetFields();
}

bool Servo::attach(uint8_t pin, uint16_t minPW, uint16_t maxPW, int16_t minAngle, int16_t maxAngle)
{
    pinMode(pin, OUTPUT);

    if (this->attached()) {
        this->detach();
    }

    this->pin = pin;
    this->minPW = (minPW);
    this->maxPW = (maxPW);
    this->minAngle = minAngle;
    this->maxAngle = maxAngle;

    const dev_pin_map_t* pwm_pin = target_pin_number_to_dev(pin, pwm_map, 0xFF);

    if (pwm_pin == NULL) {
        pr_err("pin GPIO %d is not used as PWM func\n", pin);
        return false;
    }

    this -> pwm_idx = pwm_pin->idx >> 2;
    this -> pwm_channel = pwm_pin->idx & 0x3;

    if (csi_pin_set_mux(pwm_pin->name, pwm_pin->func)) {
        pr_err("pin GPIO %d fails to config as PWM func\n", pin);
        return false;
    };

    csi_error_t ret_status = csi_pwm_init(&(this->pwm), pwm_idx);
    if (ret_status != CSI_OK) {
        pr_err("GPIO pin %d init failed\n", pin);
        return false;
    }

    csi_pwm_out_stop(&(this->pwm), this -> pwm_channel);

    csi_pwm_out_config_continuous(&(this->pwm), this -> pwm_channel, CYCLE_PERIOD_MS * 1000,
                                  CYCLE_PERIOD_MS * 1000 - 1,
                                  PWM_POLARITY_HIGH);

    this->last_PW = CYCLE_PERIOD_MS * 1000 - 1;

    return true;
}

bool Servo::detach() {
    if (!this->attached()) {
        return false;
    }

    csi_pwm_out_stop(&(this->pwm), this -> pwm_channel);

    csi_pwm_uninit(&(this->pwm));

    this->resetFields();

    return true;
}

void Servo::write(int degrees) {
    degrees = constrain(degrees, this->minAngle, this->maxAngle);
    this->writeMicroseconds(ANGLE_TO_US(degrees));
}

int Servo::read() const {
    int a = US_TO_ANGLE(this->readMicroseconds());
    return a == this->minAngle || a == this->maxAngle ? a : a + 1;
}

void Servo::writeMicroseconds(uint16_t pulseWidth) {
    if (!this->attached()) {
        return;
    }
    pulseWidth = constrain(pulseWidth, this->minPW, this->maxPW);

    csi_pwm_out_stop(&(this->pwm), this -> pwm_channel);
    csi_pwm_out_config_continuous(&(this->pwm), this -> pwm_channel, CYCLE_PERIOD_MS * 1000,
                                  pulseWidth,
                                  PWM_POLARITY_HIGH);
    this->last_PW = pulseWidth;
    csi_pwm_out_start(&(this->pwm), this -> pwm_channel);
}

uint16_t Servo::readMicroseconds() const {
    if (!this->attached()) {
        return 0;
    }

    return (this->last_PW);
}

void Servo::resetFields(void) {
    this->pin = NOT_ATTACHED;
    this->minAngle = MIN_ANGLE;
    this->maxAngle = MAX_ANGLE;
    this->minPW = MIN_PULSE_WIDTH;
    this->maxPW = MAX_PULSE_WIDTH;
    this->pwm_channel = 0;
    this->pwm_idx = 0;
    memset(&(this->pwm), 0, sizeof(csi_pwm_t));
}

#endif
